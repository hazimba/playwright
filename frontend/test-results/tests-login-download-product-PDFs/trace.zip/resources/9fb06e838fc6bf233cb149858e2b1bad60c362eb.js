//show status function
function success(msg) {
  new PNotify({
    title: 'Notification',
    text: msg,
    nonblock: true,
    history: false,
    shadow: true,
    type: 'success',
    delay: 1000
  });
}

function fail(msg) {
  if (!msg) {
    msg = "Please contact system admin";
  }
  new PNotify({
    title: 'Notification',
    text: msg,
    nonblock: true,
    history: false,
    shadow: true,
    type: 'danger',
    delay: 1000
  });
}

function printDiv(divName) {
  $("#" + divName).printMe({
    "title": "QUEST 3+"
  });
}
//
function search() {
  searchBy = $("#searchBy").val();
  proceed = false;
  if (searchBy == 0) {
    fail("Please select search by selection");
  } else {
    if (searchBy == 3) {
      searchTxt = $("#searchTxt").val();
      if (!searchTxt) {
        fail("Please enter 5 or more characters");
      } else {
        proceed = true;
      }
    } else if (searchBy == 2) {
      if ($("#searchTxt").text().length < 5) {
        fail("Please enter 5 or more characters");
      } else {
        searchTxt = $("#searchTxt").text();
        proceed = true;
      }
    } else if (searchBy == 1 || searchBy == 6 || searchBy == 4 || searchBy == 5 || searchBy == 7 || searchBy == 8) {
      if ($("#searchTxt").val().length < 5) {
        fail("Please enter 5 or more characters");
      } else {
        searchTxt = $("#searchTxt").val();
        proceed = true;
      }
    }
    if (proceed == true) {
      // if(grecaptcha.getResponse().length !== 0){
      $("#masatarikh").show();
      // var currentdate = new Date(); 
      // var datetime = "Search made on: " + currentdate.getDate() + "/"
      //             + (currentdate.getMonth()+1)  + "/" 
      //             + currentdate.getFullYear() + " @ "  
      //             + currentdate.getHours() + ":"  
      //             + currentdate.getMinutes() + ":" 
      //             + currentdate.getSeconds();

      const dateObj = new Date();

      let year = dateObj.getFullYear();

      let month = dateObj.getMonth();
      month = ('0' + (month + 1)).slice(-2);
      // To make sure the month always has 2-character-format. For example, 1 => 01, 2 => 02

      let date = dateObj.getDate();
      date = ('0' + date).slice(-2);
      // To make sure the date always has 2-character-format

      let hour = dateObj.getHours();
      hour = ('0' + hour).slice(-2);
      // To make sure the hour always has 2-character-format

      let minute = dateObj.getMinutes();
      minute = ('0' + minute).slice(-2);
      // To make sure the minute always has 2-character-format

      let second = dateObj.getSeconds();
      second = ('0' + second).slice(-2);
      // To make sure the second always has 2-character-format

      const time = `${year}/${month}/${date} ${hour}:${minute}:${second}`;
      // console.log(time);

      $("#masatarikh").html("Search made on " + time);


      $("#searchContent").show();
      $("#searchContent").html("<div class='class-col-md-12'><hr class='short alt'></div><center><img src='img/spin.gif'></center>");
      // var cat = $("#searchCat").val();
      var cat = $("input[name='searchCat']:checked").val();
      // alert(cat);
      $.ajax({
        type: "POST",
        url: "content.php",
        data: {
          func: 'search',
          searchBy: searchBy,
          searchTxt: searchTxt,
          cat: cat
        },
        success: function (data) {
          $("#searchContent").html(data);
          $('#searchTable').DataTable({
            "oLanguage": {
              "oPaginate": {
                "sPrevious": "<i class='fa fa-chevron-left' title='Previous'></i>",
                "sNext": "<i class='fa fa-chevron-right' title='Next'></i>"
              }
            },
            "iDisplayLength": 10,
            "aLengthMenu": [
              [5, 10, 25, 50, -1],
              [5, 10, 25, 50, "All"]
            ],
            //   "sDom": '<"dt-panelmenu clearfix"lTfr>t<"dt-panelfooter clearfix"ip>',
            // "oTableTools": {
            //       "sSwfPath": "vendor/plugins/datatables/extensions/TableTools/swf/copy_csv_xls_pdf.swf"
            "sDom": '<"dt-panelmenu clearfix"Blfrt>t<"dt-panelfooter clearfix"ip>',
            "oTableTools": {
              "sSwfPath": "'copy', 'csv', 'excel', 'pdf', 'print'"
            }
          });
          // grecaptcha.reset();
          searchChange();
          $("#searchTxt").html("");
        }
      });
      // }
      // else {
      //   fail("Please tick reCAPTCHA");
      // }
    }
  }
}

function searchChange() {
  searchBy = $("#searchBy").val();
  // var cat = $("#searchCat").val();
  var cat = $("input[name='searchCat']:checked").val();
  $.ajax({
    type: "POST",
    url: "content.php",
    data: {
      func: 'searchBy',
      searchBy: searchBy,
      cat: cat
    },
    success: function (data) {
      $("#searchType").html(data);
      if (searchBy == 3) {
        $('#searchTxt').select2({
          ajax: {
            url: "content.php",
            dataType: 'json',
            delay: 50,
            data: function (params) {
              return {
                func: "search",
                term: params.term,
                type: $("#searchBy").val(),
                cat: cat
              };
            },
            processResults: function (data) {
              return {
                results: data
              };
            },
            cache: true
          },
          minimumInputLength: 5,
          allowClear: false,
          templateResult: formatlocal
        });
      } else if (searchBy == 2) {
        $('#searchTxt').select2({
          ajax: {
            url: "content.php",
            dataType: 'json',
            delay: 50,
            data: function (params) {
              return {
                func: "search",
                term: params.term,
                type: $("#searchBy").val(),
                cat: cat
              };
            },
            processResults: function (data) {
              return {
                results: data
              };
            },
            cache: true
          },
          minimumInputLength: 5
        });
      }

    }
  });
}

//add by mrsb for gmp search start
function searchChangeGMP() {
  searchBy = $("#searchBy").val();
  // var cat = $("#searchCat").val();
  //var cat = $("input[name='searchCat']:checked").val();
  $.ajax({
    type: "POST",
    url: "content.php",
    data: {
      func: 'searchBy',
      searchBy: searchBy,
      //cat: cat
    },
    success: function (data) {
      $("#searchTypeGMP").html(data);
      if (searchBy == 7) {
        $('#searchTxtGMP').select2({
          ajax: {
            url: "content.php",
            dataType: 'json',
            delay: 50,
            data: function (params) {
              return {
                func: "search",
                term: params.term,
                type: $("#searchBy").val(),
                cat: cat
              };
            },
            processResults: function (data) {
              return {
                results: data
              };
            },
            cache: true
          },
          minimumInputLength: 5,
          allowClear: false,
          templateResult: formatlocal
        });
      } else if (searchBy == 8) {
        $('#searchTxtGMP').select2({
          ajax: {
            url: "content.php",
            dataType: 'json',
            delay: 50,
            data: function (params) {
              return {
                func: "search",
                term: params.term,
                type: $("#searchBy").val(),
                cat: cat
              };
            },
            processResults: function (data) {
              return {
                results: data
              };
            },
            cache: true
          },
          minimumInputLength: 5
        });
      }

    }
  });
}
//add by mrsb for gmp search end

function formatlocal(data) {
  // if (data.loading) return data.text;
  var $markup = $(
    '<table class="table table-condensed"><tr><th style="width: 30%;">Company Name</th><th style="width: 20%;">Address</th></tr><tr><td style="width: 30%;">' + data.text + '</td><td style="width: 20%;">' + data.addr + '</td></tr></table>'
  );
  return $markup;
};

function showDetail(reg) {

  var cat = $("input[name='searchCat']:checked").val();

  $.ajax({
    type: "POST",
    url: "content.php",
    data: {
      func: 'detail',
      reg: reg,
      cat: cat
    },
    success: function (data) {
      window.open(data, '_blank');
    }
  });
}

function showHolder(holder) {
  $.ajax({
    type: "POST",
    url: "content.php",
    data: {
      func: 'holder',
      holder: holder
    },
    success: function (data) {
      window.open(data, '_blank');
    }
  });
}

function searchCat(cat) {
  // alert(cat);
  $("#searchBy").children('option').show();
  if (cat == 1) {
    $("#searchBy option[value=2]").text("Product Registration Number");
  } else if (cat == 2) {
    $("#searchBy option[value=2]").text("Notification Number");
    $("#searchBy option[value=6]").hide();
  } else {
    $("#searchBy option[value=4]").hide();
    $("#searchBy option[value=5]").hide();
    $("#searchBy option[value=6]").hide();
  }
  $('#searchBy').prop('selectedIndex', 0);
  $('#searchTxt').prop('disabled', true);
}